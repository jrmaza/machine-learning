COLUMN KEY FOR SOLUBILITY DATA
===============================================================================
StdInChIKey = StdInChIKey for molecule; unique identifier
SMILES = SMILES code for molecule
LogS = Solubility (log base 10 C, where C = concentration in units mol/L)
T = Temperature of measurement
Source = Source of solubility measurement
REF1, REF2, REF3 etc. = Reference(s) for solubility measurement; only for water